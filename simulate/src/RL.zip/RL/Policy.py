import gymnasium as gym
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env


model = PPO.load("/home/jang/unitree_mujoco/simulate/src/RL/ppo_cartpole")
vec_env = make_vec_env("CartPole-v1", n_envs=1)
def get_action(state):
    # Convert state to a NumPy array
    # state = np.array(state).reshape(1, -1)
    
    # Get action from the model (deterministic=True for evaluation)
    action, state = model.predict(state, deterministic=True)
    obs, rewards, dones, info = vec_env.step(action)
    print("obs: ",obs)
    return obs[0].tolist()